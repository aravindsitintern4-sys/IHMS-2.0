package stepDefinitions;

import io.cucumber.java.en.*;
import org.testng.Assert;
import hooks.Hooks;
import pages.billentryPage;
import locators.billentryLocator;

public class billentrySteps {
    
    billentryPage billPage = new billentryPage(Hooks.driver);

    @Given("user is on the billing entry page")
    public void user_is_on_the_billing_entry_page() {
        billPage.openBillingPage(); 
    }
    
    @When("user enters UIN {string}")
    public void user_enters_uin(String uin) {
        billPage.enterUIN(uin);
    }

    @And("user presses the \"ENTER\" key on the UIN field")
    public void user_presses_enter(String key) {
        billPage.pressEnterOnUIN();
    }

    @Then("the patient name should be displayed as {string}")
    public void verify_patient_name(String expectedName) {
        String actualName = billPage.getPatientName();
        Assert.assertEquals(actualName, expectedName, "Patient name mismatch!");
    }

    @And("user selects Pay\\/Free as {string}")
    public void user_selects_pay_free(String mode) {
        billPage.selectPayFree(mode);
    }

    @And("user selects Advised By as {string}")
    public void user_selects_advised_by(String doctor) {
        billPage.selectAdvisedBy(doctor);
    }

    @Then("selected Pay\\/Free option should displayed")
    public void verify_pay_selection() {
        String selected = billPage.getSelectedOption(billentryLocator.paymentTypeDropdown);
        Assert.assertFalse(selected.isEmpty(), "Pay/Free selection is empty!");
    }

    @Then("selected Advised By option should displayed")
    public void verify_advised_selection() {
        String selected = billPage.getSelectedOption(billentryLocator.AdviseByDropdown);
        Assert.assertFalse(selected.equalsIgnoreCase("Select"), "Doctor was not selected!");
    }
}