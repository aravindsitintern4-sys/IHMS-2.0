package hooks;

import io.cucumber.java.Before;
import io.cucumber.java.After;
import org.openqa.selenium.WebDriver;
import utils.DriverFactory;

public class Hooks {

    private static boolean isBrowserStarted = false;
    public static WebDriver driver;

    @Before
    public void setup() {
        if (!isBrowserStarted) {
            DriverFactory.initDriver();
//            DriverFactory.getDriver().get("https://eyenotes20-base-qa.aravind.org:30434/login");
            driver = DriverFactory.getDriver();  
            isBrowserStarted = true;
        }
    }

    @After
    public void tearDown() {
        // DriverFactory.quitDriver();
    }
}