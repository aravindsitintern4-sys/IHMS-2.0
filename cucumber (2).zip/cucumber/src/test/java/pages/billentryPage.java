package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions; 
import org.openqa.selenium.support.ui.*;

import locators.billentryLocator;
import java.time.Duration;

public class billentryPage {
    WebDriver driver;
    WebDriverWait wait;
    Actions actions; 

    public billentryPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        this.actions = new Actions(driver);
    }
    
    public void openBillingPage() {
        driver.get("xxxx"); 
        driver.manage().window().maximize();
        wait.until(ExpectedConditions.visibilityOfElementLocated(billentryLocator.uinInput));
    }

    public void enterUIN(String uin) {
        WebElement uinField = wait.until(
            ExpectedConditions.elementToBeClickable(billentryLocator.uinInput)
        );

        uinField.click();

        uinField.sendKeys(Keys.CONTROL + "a");
        uinField.sendKeys(Keys.DELETE);

        uinField.sendKeys(uin);

        String enteredValue = uinField.getAttribute("value");

        if (enteredValue == null || enteredValue.isEmpty()) {
            ((JavascriptExecutor) driver).executeScript(
                "arguments[0].value=arguments[1]; arguments[0].dispatchEvent(new Event('input'));",
                uinField, uin
            );
        }

        System.out.println("Entered UIN: " + uin);
    }

    public void pressEnterOnUIN() {
        WebElement uinField = driver.findElement(billentryLocator.uinInput);
        
        uinField.sendKeys(Keys.ENTER);
        
        wait.until(d -> {
            String val = d.findElement(billentryLocator.patientNameDisplay).getAttribute("value");
            return val != null && val.trim().length() > 0;
        });
    }

    
    public String getPatientName() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(billentryLocator.patientNameDisplay))
                   .getAttribute("value").trim();
    }

    public void selectPayFree(String mode) {
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(billentryLocator.paymentTypeDropdown));
        Select select = new Select(dropdown);
        select.selectByVisibleText(mode.toUpperCase());
    }

    public void selectAdvisedBy(String doctorName) {
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(billentryLocator.AdviseByDropdown));
        Select select = new Select(dropdown);
        
        for (WebElement option : select.getOptions()) {
            if (option.getText().trim().equalsIgnoreCase(doctorName.trim())) {
                select.selectByVisibleText(option.getText());
                break;
            }
        }
    }

    public String getSelectedOption(By locator) {
        Select select = new Select(driver.findElement(locator));
        return select.getFirstSelectedOption().getText().trim();
    }
}