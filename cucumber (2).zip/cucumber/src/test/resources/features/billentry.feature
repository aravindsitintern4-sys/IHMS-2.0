@login @dashboard @billing
@billentry

Feature: Billing Patient Management

  Background:
    Given user is on the billing entry page

  Scenario Outline: Verify billing details for different patients and payment modes
    When user enters UIN "<UINNumber>"
    And user presses the "ENTER" key on the UIN field
    Then the patient name should be displayed as "<ExpectedName>"
    And user selects Pay/Free as "<PaymentMode>"
    And user selects Advised By as "<AdvisedBy>"
    Then selected Pay/Free option should displayed 
    And selected Advised By option should displayed
    Then user clicks on Cancel button

    Examples:
      | UINNumber  | ExpectedName | PaymentMode | AdvisedBy |
      | 0024425296 | Aff S        | PAY         | Ashwin B  |
      | 0024425296 | Aff S        | FREE        | Rupa a    |