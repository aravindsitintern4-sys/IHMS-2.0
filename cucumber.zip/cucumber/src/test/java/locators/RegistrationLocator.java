package locators;

import org.openqa.selenium.By;

public class RegistrationLocator {

	public static By opModulesMenu = By.xpath("//span[contains(text(),'OP Modules')]");

	public static By outpatientRegistration = By.xpath("//a[normalize-space()='Outpatient Registration']");
	
	public static By getMenuOption(String optionName) {
	    return By.xpath("//a[normalize-space()='" + optionName + "']");
	}
}
