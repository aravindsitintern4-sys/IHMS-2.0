package stepDefinitions;

import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import pages.RegistrationPage;
import utils.DriverFactory;

public class registrationSteps {

    WebDriver driver = DriverFactory.getDriver();
    RegistrationPage registrationPage = new RegistrationPage(driver);

    @When("user navigates to OP Module and selects {string}")
    public void navigate_to_op_registration(String optionName) {
        registrationPage.selectOutpatientRegistration(optionName);
    }

    @Then("the op registration page should be displayed")
    public void verify_op_registration_page() {

        Assert.assertTrue(registrationPage.isOPRegistrationPageLoaded(),
                "Navigation failed: OP Registration page not loaded");

        System.out.println("OP Registration Page Loaded Successfully");
    }
}