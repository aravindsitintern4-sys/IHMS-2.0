package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import java.time.Duration;

import locators.RegistrationLocator;

public class RegistrationPage {

    private WebDriver driver;
    private WebDriverWait wait;
    private Actions actions;

    public RegistrationPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        this.actions = new Actions(driver);
    }

    public void selectOutpatientRegistration(String optionName) {

        WebElement menu = wait.until(
                ExpectedConditions.visibilityOfElementLocated(
                        RegistrationLocator.opModulesMenu)
        );

        ((JavascriptExecutor) driver).executeScript(
            "arguments[0].dispatchEvent(new MouseEvent('mouseover', {bubbles:true}))",
            menu
        );

        try { Thread.sleep(500); } catch (Exception e) {}

        WebElement option = wait.until(
                ExpectedConditions.visibilityOfElementLocated(
                        RegistrationLocator.getMenuOption(optionName))
        );

        option.click();
    }
    public boolean isOPRegistrationPageLoaded() {
        try {
            return wait.until(ExpectedConditions.urlContains("registration"));
        } catch (Exception e) {
            System.out.println("OP Registration page not loaded: " + e.getMessage());
            return false;
        }
    }
}