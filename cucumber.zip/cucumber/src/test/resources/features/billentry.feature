@login @dashboard @billing
@billentry

Feature: Billing Patient Management

  Background:
    Given user is on the billing entry page

  Scenario Outline: Verify billing details for different patients and payment modes
    When user enters UIN "0024425387" and presses enter
    Then patient details should be displayed

    And user clicks Pay/Free dropdown 
    And user selects "<PaymentMode>" from Pay/Free dropdown 

    And user clicks Advised By dropdown
    And user selects "<AdvisedBy>" from Advised By dropdown

    Then selected "<PaymentMode>" option should be displayed
    And selected "<AdvisedBy>" option should be displayed

#    And user clicks Cancel button

Examples:
| PaymentMode | AdvisedBy |
| PAY         | Ashwin B  |
| FREE        | Rupa A    |