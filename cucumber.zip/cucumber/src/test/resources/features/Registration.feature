@login @dashboard
@Registration

Feature: Registration 

  Scenario: Navigate to Regiatration Page
    Given user is on ihms dashboard
    When user navigates to OP Module and selects "Outpatient Registration"
    Then the op registration page should be displayed