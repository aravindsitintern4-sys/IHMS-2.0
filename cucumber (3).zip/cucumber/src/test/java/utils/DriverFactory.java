package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.PageLoadStrategy;

import java.time.Duration;

public class DriverFactory {

    private static final ThreadLocal<WebDriver> driver = new ThreadLocal<>();

    public static void initDriver() {

        WebDriverManager.chromedriver().setup();

        ChromeOptions options = new ChromeOptions();

        options.addArguments("--start-maximized");

        options.addArguments("--ignore-certificate-errors");
        options.addArguments("--allow-running-insecure-content");
        options.addArguments("--disable-web-security");
        options.addArguments("--remote-allow-origins=*");

        options.setAcceptInsecureCerts(true);

        options.setPageLoadStrategy(org.openqa.selenium.PageLoadStrategy.EAGER);     

        WebDriver webDriver = new ChromeDriver(options);

        webDriver.manage().deleteAllCookies();

        webDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
        webDriver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(120));

        driver.set(webDriver);
    }

    public static WebDriver getDriver() {
        if (driver.get() == null) {
            initDriver();
        }
        return driver.get();
    }

    public static void quitDriver() {
        if (driver.get() != null) {
            driver.get().quit();
            driver.remove();
        }
    }
}