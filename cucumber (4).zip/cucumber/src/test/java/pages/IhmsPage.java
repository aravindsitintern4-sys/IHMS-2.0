package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import java.time.Duration;
import java.util.Set;
import locators.IhmsLocator;

public class IhmsPage {

    WebDriver driver;
    WebDriverWait wait;

    public IhmsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(40));
    }

    public void waitForDashboardToLoad() {
        wait.until(d -> ((JavascriptExecutor)d)
            .executeScript("return document.readyState").equals("complete"));
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(IhmsLocator.ihmslogin));
    }

    public void clickIHMSModule() {
        // 1. Store the ID of the current window
        String mainWindow = driver.getWindowHandle();

        WebElement ihmsCard = wait.until(ExpectedConditions.elementToBeClickable(IhmsLocator.ihmslogin));
        ihmsCard.click();
        System.out.println("Clicked IHMS Module.");

        // 2. CHECK FOR NEW WINDOW (Crucial for blank page issues)
        // If a new tab opened, we MUST switch to it
        wait.until(d -> d.getWindowHandles().size() > 1 || ((JavascriptExecutor)d).executeScript("return document.readyState").equals("complete"));
        
        Set<String> allWindows = driver.getWindowHandles();
        for (String window : allWindows) {
            if (!window.equals(mainWindow)) {
                driver.switchTo().window(window);
                System.out.println("Switched to new tab/window.");
            }
        }

        // 3. WAIT FOR IFRAME & SWITCH
        // Instead of a simple if/else, we use the explicit wait for the frame
        try {
            // This waits for the iframe to exist AND switches the driver into it
            wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.tagName("iframe")));
            System.out.println("Switched into the IHMS iframe.");
        } catch (TimeoutException e) {
            System.out.println("No iframe found within 40s. Checking main content...");
        }

        // 4. VERIFY CONTENT (Don't leave until an element appears)
        // This stops the code from proceeding while the page is still white
        wait.until(ExpectedConditions.visibilityOfElementLocated(IhmsLocator.ihmsMenu));
        System.out.println("IHMS Menu is now visible. Page is no longer blank.");
    }

    public boolean isIHMSPageDisplayed() {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(IhmsLocator.ihmsMenu)).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}