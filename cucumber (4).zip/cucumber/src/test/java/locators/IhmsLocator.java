package locators;

import org.openqa.selenium.By;

public class IhmsLocator {

	    public static By ihmslogin = By.xpath("//div[normalize-space()='IHMS']");
	    
	    public static By ihmsMenu = By.cssSelector("app-menu");  
	    
	    public static By ihmsHeader = By.xpath("//h1[text()='IHMS']");
}