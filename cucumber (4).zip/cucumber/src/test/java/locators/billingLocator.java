package locators;

import org.openqa.selenium.By;

public class billingLocator {

    public static By billingMenu = By.xpath("//span[normalize-space()='Billing']");

    public static By billEntryOption = By.xpath("//span[normalize-space()='Billing']/parent::div//a[normalize-space()='Bill Entry']");
}