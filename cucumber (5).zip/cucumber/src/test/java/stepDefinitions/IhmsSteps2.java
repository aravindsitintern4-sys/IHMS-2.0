package stepDefinitions;

import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import pages.IhmsPage;
import utils.DriverFactory;

public class IhmsSteps2 {

    private WebDriver driver;
    private IhmsPage ihmsPage;

    public IhmsSteps2() {
        this.driver = DriverFactory.getDriver();
        this.ihmsPage = new IhmsPage(driver);
    }

    @Given("user is on dashboard")
    public void user_is_on_dashboard() {
        // ihmsPage.waitForDashboardToLoad(); 
    }

    @When("user selects the IHMS module")
    public void user_selects_ihms_module() {
        ihmsPage.clickIHMSModule();
    }

    @Then("IHMS dashboard page should be displayed")
    public void verify_ihms_dashboard_page() {
        boolean isDisplayed = ihmsPage.isIHMSPageDisplayed();
        
        Assert.assertTrue(isDisplayed, "IHMS Dashboard failed to load (Page stayed blank).");
        System.out.println("IHMS UI is visible and active.");
    }
}