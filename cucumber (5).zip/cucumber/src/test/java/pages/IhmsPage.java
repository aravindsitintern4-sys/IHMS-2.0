package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import java.time.Duration;
import java.util.Set;
import locators.IhmsLocator;

public class IhmsPage {
    private final WebDriver driver;
    private final WebDriverWait wait;

    public IhmsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(30));
    }

    public void clickIHMSModule() {
        String originalWindow = driver.getWindowHandle();
        
        // 1. Click the module
        WebElement card = wait.until(ExpectedConditions.elementToBeClickable(IhmsLocator.ihmslogin));
        card.click();

        // 2. Switch to the NEW Tab
        wait.until(ExpectedConditions.numberOfWindowsToBe(2));
        Set<String> allWindows = driver.getWindowHandles();
        for (String handle : allWindows) {
            if (!handle.equals(originalWindow)) {
                driver.switchTo().window(handle);
                break;
            }
        }

        // 3. THE BLANK PAGE FIX
        // Wait for the URL to stabilize (stop being about:blank)
        wait.until(d -> !d.getCurrentUrl().equals("about:blank"));

        // 4. SWITCH TO IFRAME (Try twice)
        try {
            switchToIframeAndCheckContent();
        } catch (Exception e) {
            System.out.println("Content not found. Refreshing tab to force load...");
            driver.navigate().refresh();
            switchToIframeAndCheckContent();
        }
    }

    private void switchToIframeAndCheckContent() {
        // Switch to the iframe
        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(IhmsLocator.ihmsIframe));
        
        // Wait for a real element inside the frame to prove it's NOT blank
        // If this fails, the 'catch' block above will trigger a refresh
        wait.until(ExpectedConditions.visibilityOfElementLocated(IhmsLocator.ihmsMenu));
        System.out.println("IHMS Content successfully loaded inside Iframe.");
    }
    
    public boolean isIHMSPageDisplayed() {
        try {
            // We use wait.until to give the Angular UI a moment to 'appear' 
            // after the iframe switch.
            WebElement menu = wait.until(ExpectedConditions.visibilityOfElementLocated(IhmsLocator.ihmsMenu));
            return menu.isDisplayed();
        } catch (Exception e) {
            System.out.println("IHMS Menu not found. Page might still be blank.");
            return false;
        }
    }
}